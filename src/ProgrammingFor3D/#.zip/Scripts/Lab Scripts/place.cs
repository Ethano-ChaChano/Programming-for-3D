namespace EntryPoints
{
    public enum place
    {
        NONE,
        SKATEBOARD,
        PLATFORM,
        FIRE,
        SOUNDSYSTEM,
        TELEVISION,
    }
}